<html>

<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>About TOASTpix</title>
  <link href="css/toast.css" rel="stylesheet">
</head>

<body>
<div class="f1_container">
    <div class="shadow f1_card">
        <div class="front face">
            <img src="http://media-cdn.tripadvisor.com/media/photo-s/03/48/0b/14/dolphin-view-chalets.jpg" style="height: 281px; width: 450px;" />
        </div>
        <div class="back face center">Some text inside here</div>
    </div>
</div>




<script src="http://lib.sinaapp.com/js/jquery/1.9.1/jquery-1.9.1.js
"></script>
<script >
	$('.f1_container').click(function() {
    $(this).toggleClass('active');
});
</script>





</body>