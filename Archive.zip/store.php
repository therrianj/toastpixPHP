<?php
   // SOMETHING DONE


require 'header.php';


header("location: https://master.d34xu9y1b294jm.amplifyapp.com/");

   ?>
