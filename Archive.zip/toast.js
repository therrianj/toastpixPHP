$(document).ready(function(){
	$("#card").flip({
	  axis: 'x',
	  trigger: 'click'
	})
});