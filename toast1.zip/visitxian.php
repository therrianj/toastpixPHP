<?php
   // SOMETHING DONE


require 'header.php';


header("location: http://visitxian-env-2.eba-shhvbgad.us-east-2.elasticbeanstalk.com");

   ?>